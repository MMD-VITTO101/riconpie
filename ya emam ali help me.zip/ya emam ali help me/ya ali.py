from urllib.parse import*
import requests
from bs4 import*
import socket
import re
from collections import deque
import dns.resolver
from termcolor import colored
import csv
import whois



input_url=input(colored("enter your favorite link : " , "magenta"))
if not input_url.startswith(('http://','https://')):
    url='https://'+input_url





deps=set()
full_links=set()

earn_link=urlparse(url).netloc
lineup=deque([(url,0)])



with open('recon pie.csv',mode="w",newline="",encoding="utf-8",) as cf:
    list=["deps","Ip","Number Phone","ip","Emails",]
    w=csv.DictWriter(cf, fieldnames=list)
    w.writeheader()


    while lineup:
        frist_url,omgh=lineup.popleft()

        if omgh>2:
            continue
    
        if frist_url in deps:
            continue

        deps.add(frist_url)


        print(colored(f" omgh {omgh}: {frist_url}","light_magenta"))
        print(colored("<<.................>>" , "blue"))




        Getting_permission=requests.get(frist_url)
        if Getting_permission.status_code==200:
            status_ejazeh=BeautifulSoup(Getting_permission.text,"html.parser")






            damane=urlparse(frist_url).netloc
            ip = socket.gethostbyname(damane)
            
            print(colored(f"IP page:{ip}" , 'light_yellow'))
            print(colored("<<.................>>" , "blue"))






            number_phone = [
            r'\+98[\s\-]?[\d۰-۹]{2,3}[\s\-]?[\d۰-۹]{3}[\s\-]?[\d۰-۹]{4}',
            r'0[\d۰-۹]{2,3}[\s\-]?[\d۰-۹]{3}[\s\-]?[\d۰-۹]{4}',
            r'[\d۰-۹]{3,4}[\s\-]?[\d۰-۹]{3,4}[\s\-]?[\d۰-۹]{3,4}',
            r'۰۹[\d۰-۹]{2}[\s\-]?[\d۰-۹]{3}[\s\-]?[\d۰-۹]{4}',
            r'۰۹[\d۰-۹]{9}', 
            ]


            numbers = set()
            text = status_ejazeh.get_text()
            for a in number_phone:
                mmd = re.findall(a, text)
                for mah in mmd:
                 numbers.add(mah.strip())


            if numbers:
                print(colored(f"Number found:" , "light_green"))
                for phone in numbers:
                    print(f"{phone}")
                    print(colored("<<.................>>" , "blue"))


            else:
                print(colored(f"Number not found." , "light_red"))








            full_emails= r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
            email = set(re.findall(full_emails, text, re.IGNORECASE))


            for a in status_ejazeh.find_all("a", href=True):
                if a['href'].startswith('mailto:'):
                    emails = a['href'][7:].split('?')[0].strip()
                    if re.match(full_emails, emails):
                        email.add(emails)




            
            if email:
                print(colored('Email found:' , "light_green"))
                for amal in email:
                    print(colored(f"{amal}" , "white"))
                    print(colored("<<.................>>" , "blue"))





            else:
                print(colored("email not found." , "light_red"))





            the_ports=[21, 22, 23, 25, 53, 80, 110, 119, 123, 143, 161, 194 , 443, 445, 993 , 995, 3306, 8080]
                      

            for port in the_ports:


                s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)


                s.settimeout(1)


                final=s.connect_ex((ip,port))


                if final==0:
                    print(colored(f"port is open:{port}" , "green"))


                else:
                    print(colored(f"port isnt open: {port}" , "red"))


                s.close()







            

            for a in status_ejazeh.find_all("a",href=True):
                href=a["href"]
                final_url=urljoin(frist_url,href)
                parsed=urlparse(final_url)
                full_links.add(frist_url)




                if parsed.scheme in ('http', 'https') and parsed.netloc.endswith(earn_link):
                    if final_url not in full_links:
                        full_links.add(final_url)
                        if omgh<2:
        
                            lineup.append((final_url,omgh+1))




        else:

            print(colored(f"error page{Getting_permission.status_code}:{input_url}" , "red"))
            print(colored("<<.................>>" , "blue"))


        onvan =status_ejazeh.title.string
        print(f"title:{onvan}")





    error = [400, 401, 403, 404, 405, 422, 429]
    taghiir = [301, 302, 304]
    Server_error = [500, 502, 503, 504]
    Victory = [200, 201, 204]



    for link02 in full_links:
        z = requests.get(link02, timeout=3)
        code = z.status_code
        
        if code in Victory:
            print(f"[{code}]{link02}")
        elif code in error:
            print(f"[{code}] {link02}")
        elif code in taghiir:
            print(f"[{code}]{link02}")
        elif code in Server_error:
            print(f"[{code}]{link02}")
        else:
            print(f"[{code}]{link02}")